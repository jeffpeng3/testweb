"""
NTUST course order suggestion system
"""
import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW
import httpx

class Course_order_suggestion_system(toga.App):
    def startup(self):
        """Construct and show the Toga application.

        Usually, you would add your application to a main content box.
        We then create a main window (with a name matching the app), and
        show the main window.
        """
        main_box = toga.Box(style=Pack(direction=COLUMN))

        name_label = toga.Label(
            "Your name: ",
            style=Pack(padding=(0, 5))
        )
        self.name_input = toga.TextInput(style=Pack(flex=1))
        self.output_label = toga.Label(
            "Hello, world!",
            style=Pack(padding=(0, 5))
        )

        name_box = toga.Box(style=Pack(direction=ROW, padding=5))
        name_box.add(name_label)
        name_box.add(self.name_input)
        

        button = toga.Button(
            "Say Hello!",
            on_press=self.say_hello,
            style=Pack(padding=5)
        )

        main_box.add(name_box)
        main_box.add(button)
        main_box.add(self.output_label)


        self.main_window = toga.MainWindow(title=self.formal_name)
        self.main_window.content = main_box
        self.main_window.show()

    async def say_hello(self, widget):
        async with httpx.AsyncClient() as client:
            data = {"Semester": '1122', "CourseNo": self.name_input.value, "Language": "zh"}
            api = "https://querycourse.ntust.edu.tw/querycourse/api/courses"
            response = await client.post(api, data=data)

        payload = response.json()[0]

        self.output_label.text = payload

def main():
    return Course_order_suggestion_system()

